import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'gleasonapp';
  isLogin=true;
  isDashboard=false;

  handleLogin(){
    this.isLogin=false;
    this.isDashboard=true;
  }
}
