import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalSuccesComponentComponent } from './modal-succes-component.component';

describe('ModalSuccesComponentComponent', () => {
  let component: ModalSuccesComponentComponent;
  let fixture: ComponentFixture<ModalSuccesComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModalSuccesComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalSuccesComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
