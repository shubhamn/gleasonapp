import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { ModalSuccesComponentComponent } from '../modal-succes-component/modal-succes-component.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  @Output() loginEvent = new EventEmitter();

  constructor(private dialog: MatDialog) { }

  ngOnInit() {
  }

  onLogin(){
   /* const dialogConfig = new MatDialogConfig();
    dialogConfig.data = {
        data: 'Login successfull!'
      };
   let dialogRef= this.dialog.open(ModalSuccesComponentComponent, dialogConfig);
   dialogRef.afterClosed().subscribe(result =>{
    console.log("closeddd");})*/
    this.loginEvent.emit()
  }

}
