import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

   cardData=[{name:'Users',score:64},{name:'Applications',score:32},{name:'modules',score:110},{name:'Packages',score:50}]
  
  constructor() { }

  ngOnInit() {
  }

}
