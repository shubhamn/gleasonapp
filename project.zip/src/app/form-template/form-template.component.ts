import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-template',
  templateUrl: './form-template.component.html',
  styleUrls: ['./form-template.component.css']
})
export class FormTemplateComponent implements OnInit {
  listItem=['Global Reason Academy','User','Cutomer admin','Gleason Regional Sales','Gleason Internal Sales','Gleason Enginer']
  constructor() { }

  ngOnInit() {
  }

}
