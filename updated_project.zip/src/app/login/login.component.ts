import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { ModalSuccesComponentComponent } from '../modal-succes-component/modal-succes-component.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  @Output() loginEvent = new EventEmitter();
  loginform:FormGroup;
  msg='';
  constructor(private fb:FormBuilder,private dialog: MatDialog) { }

  ngOnInit() {
    this.loginform=this.fb.group({
      name:['',Validators.required],
      password:['',Validators.required]
    })
  }

  onLogin(){
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = {
        data: 'Login successfull!'
      };
   let dialogRef= this.dialog.open(ModalSuccesComponentComponent, dialogConfig);
   dialogRef.afterClosed().subscribe(result =>{
    console.log("closeddd");
    this.loginEvent.emit()})
  }

}
