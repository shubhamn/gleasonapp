import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-usermanagement',
  templateUrl: './usermanagement.component.html',
  styleUrls: ['./usermanagement.component.css']
})
export class UsermanagementComponent implements OnInit {
  @Output() userEvent = new EventEmitter();
  @Output() doneEvent = new EventEmitter();
  @Output() deleteEvent = new EventEmitter();
  constructor() { }
  user;
  address;
  customer;
  isDelete=true;
  isEdit=true;
  customerVal;
  isFieldDisabled=true;
  isDone=false;
  role;
  isSelected:any;
  trialUser;
  @Input() customers:any;
  @Input() customerData: any
  ngOnInit() {
  }
  selectedValue(arg){
    console.log('arg',arg);
    this.customerVal=arg
    this.isSelected=true;
    this.user=this.customerData[arg]['user'];
    this.address=this.customerData[arg]['address'];
    this.customer=this.customerData[arg]['customer'];
    this.role=this.customerData[arg]['role'];
    this.trialUser=this.customerData[arg]['trialuser']
  }

  add(){
    this.userEvent.emit();
  }

  done(){
    let ob={user:this.user,data:{'user':this.user,'address':this.address,'customer':this.customer,'role':this.role,'trialuser':this.trialUser}};
    this.doneEvent.emit(ob);
    this.isDone=true;
    this.isDelete=true;
    this.isEdit=true;
    this.isFieldDisabled=true;
  }

  delete(){
    this.deleteEvent.emit(this.user)
    this.user='';
    this.address='';
    this.customer='';
    this.role='';
    this.trialUser='';
    this.isSelected=false;
  }

  close(){
    this.isFieldDisabled=true;
    this.isDelete=true;
    this.isEdit=true;
    this.isSelected=true;
  }

}
