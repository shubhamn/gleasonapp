import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-form-template',
  templateUrl: './form-template.component.html',
  styleUrls: ['./form-template.component.css']
})
export class FormTemplateComponent implements OnInit {
  @Output() formEvent = new EventEmitter();
  listItem=['Global Reason Academy','User','Cutomer admin','Gleason Regional Sales','Gleason Internal Sales','Gleason Enginer']
  customers=['shubham','naman','karan','suman','mahima'];
  customerData={'shubham':{'user':'shubham','address':'shubham@h.co','customer':'sh','role':'jd','trialuser':'dd'},'naman':{'user':'naman','address':'naman@h.co','customer':'shss','role':'ddjd','trialuser':'dddd'},'karan':{'user':'karan','address':'karan@h.co','customer':'shdd','role':'jddd','trialuser':'dddd'},'suman':{'user':'suman','address':'suman@h.co','customer':'ddsh','role':'jddd','trialuser':'dad'},'mahima':{'user':'mahima','address':'mahima@h.co','customer':'shs','role':'jds','trialuser':'ddd'}}
  check;
  user;
  address;
  customer;
  customerVal;
  role;
  trialUser;
  constructor() { }

  ngOnInit() {
  }

  task = {
    name: 'Indeterminate',
    completed: false,
    color: 'primary',
    subtasks: [
      {name: 'Global Gleason admin', completed: false, color: 'primary'},
      {name: 'user', completed: false, color: 'primary'},
      {name: 'Gleason Regional Sales Manager', completed: false, color: 'primary'},
      {name: 'Gleason Internal Sale', completed: false, color: 'primary'},
      {name: 'Gleason Enginer', completed: false, color: 'primary'}
    ]
  };

  allComplete: boolean = false;

  updateAllComplete() {
    console.log("task1",this.task)
    this.task.subtasks.forEach(t => {if(t.completed){
      this.role=t.name;
    }})
    this.allComplete = this.task.subtasks != null && this.task.subtasks.every(t => t.completed);
    console.log("check",this.role);
  }

  someComplete(): boolean {
    console.log("task2",this.task)
    if (this.task.subtasks == null) {
      return false;
    }
    return this.task.subtasks.filter(t => t.completed).length > 0 && !this.allComplete;
  }

  setAll(completed: boolean) {
    console.log("task3",this.task)
    this.allComplete = completed;
    if (this.task.subtasks == null) {
      return;
    }
    this.task.subtasks.forEach(t => t.completed = completed);
  }

  add(){
    console.log("add");
    let ob={}
    ob['user']=this.user;
    ob['address']=this.address;
    ob['customer']=this.customer;
    ob['role']=this.role;
    ob['trialUser']=this.trialUser;
    this.customerData[this.user]=ob;
    this.customers.push(this.user);
    let ob1={'users':this.customers,'userData':this.customerData}
   this.formEvent.emit(ob1)
  }

  selectedValue(arg){

  }

}


