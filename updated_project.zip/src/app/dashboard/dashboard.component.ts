import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

   cardData=[{name:'Users',score:64,icon:'cloud_upload'},{name:'Applications',score:32,icon:'published_with_changes'},{name:'modules',score:110,icon:'cached'},{name:'Packages',score:50,icon:'ios_share'}]
  
  constructor() { }

  ngOnInit() {
  }

}
