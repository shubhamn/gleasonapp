import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-modal-succes-component',
  templateUrl: './modal-succes-component.component.html',
  styleUrls: ['./modal-succes-component.component.css']
})
export class ModalSuccesComponentComponent implements OnInit {

  data:any;

  constructor(private dialogRef: MatDialogRef<ModalSuccesComponentComponent>,
    @Inject(MAT_DIALOG_DATA) data) {
      this.data = data['data'];
     }

  ngOnInit() {
  }

  close() {
    this.dialogRef.close();
  }
}
