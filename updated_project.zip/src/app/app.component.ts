import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'gleasonapp';
  isLogin=true;
  isForm=false;
  isDashboard=false;
  isManagement=false;
  isSidebar=false;
  customers=['shubham','naman','karan','suman','mahima'];
  customerData={'shubham':{'user':'shubham','address':'shubham@h.co','customer':'sh','role':'jd','trialuser':'dd'},'naman':{'user':'naman','address':'naman@h.co','customer':'shss','role':'ddjd','trialuser':'dddd'},'karan':{'user':'karan','address':'karan@h.co','customer':'shdd','role':'jddd','trialuser':'dddd'},'suman':{'user':'suman','address':'suman@h.co','customer':'ddsh','role':'jddd','trialuser':'dad'},'mahima':{'user':'mahima','address':'mahima@h.co','customer':'shs','role':'jds','trialuser':'ddd'}}

  handleLogin(){
    this.isLogin=false;
    this.isDashboard=true;
    this.isSidebar=true;
  }

  handleDone(arg){
    this.customerData[arg.user]=arg.data;
  }

  handleForm(arg){
    this.customerData=arg.userData;
    this.customers=arg.users;
    this.isForm=false;
    this.isSidebar=true;
    this.isManagement=true;
  }

  handleDelete(arg){
    delete this.customerData[arg]
    const index = this.customers.indexOf(arg);
    if (index > -1) {
  this.customers.splice(index, 1);
  }
  }
  handleUser(){
    this.isDashboard=false;
    this.isManagement=false;
    this.isSidebar=false;
    this.isForm=true;
  }

  handleSide(arg){
    if(arg === 'Dashboard'){
      this.isDashboard=true;
      this.isManagement=false;
    }
    else if(arg === 'User'){
      this.isDashboard=false;
      this.isManagement=true;
    }

  }
}
